import { Component } from '@angular/core';

@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [],
  templateUrl: './add-trip.component.html',
  styleUrl: './add-trip.component.css'
})
export class AddTripComponent {

}
